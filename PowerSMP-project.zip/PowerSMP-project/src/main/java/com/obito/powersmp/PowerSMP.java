package com.obito.powersmp;

import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;

public final class PowerSMP extends JavaPlugin implements Listener {
  private final List<String> powers = List.of("LIGHTNING","FIRE","ICE","TELEPORT","SPEED");
  private final Map<UUID,Long> cooldowns = new HashMap<>();
  private NamespacedKey itemKey;
  @Override public void onEnable(){ itemKey=new NamespacedKey(this,"power_item"); saveDefaultConfig(); getServer().getPluginManager().registerEvents(this,this); getLogger().info("PowerSMP enabled"); }
  @EventHandler public void join(PlayerJoinEvent e){ Player p=e.getPlayer(); String path="players."+p.getUniqueId(); if(!getConfig().contains(path)){ String power=powers.get(new Random().nextInt(powers.size())); getConfig().set(path,power); saveConfig(); givePowerItem(p,power); p.sendMessage("§6[PowerSMP] §aYour permanent power is §e"+pretty(power)); } }
  private String power(Player p){ String path="players."+p.getUniqueId(); String v=getConfig().getString(path); if(v==null||!powers.contains(v)){v=powers.get(new Random().nextInt(powers.size()));getConfig().set(path,v);saveConfig();} return v; }
  private String pretty(String s){return switch(s){case "LIGHTNING"->"Lightning";case "FIRE"->"Fire";case "ICE"->"Ice";case "TELEPORT"->"Teleport";default->"Super Speed";};}
  private Material material(String s){return switch(s){case "LIGHTNING"->Material.BLAZE_ROD;case "FIRE"->Material.FIRE_CHARGE;case "ICE"->Material.PRISMARINE_SHARD;case "TELEPORT"->Material.ENDER_PEARL;default->Material.DIAMOND_BOOTS;};}
  private ItemStack makeItem(String s){ ItemStack it=new ItemStack(material(s)); ItemMeta m=it.getItemMeta(); m.setDisplayName("§6"+pretty(s)+(s.equals("SPEED")?" Boots":" Power Item")); m.getPersistentDataContainer().set(itemKey,PersistentDataType.STRING,s); m.setLore(List.of("§7Bound to your permanent power","§eRight-click to activate")); it.setItemMeta(m); return it; }
  private void givePowerItem(Player p,String s){ if(s.equals("SPEED")){p.getInventory().addItem(makeItem(s));} else p.getInventory().addItem(makeItem(s)); }
  @EventHandler public void interact(PlayerInteractEvent e){ if(e.getHand()!=EquipmentSlot.HAND)return; if(e.getAction()!=org.bukkit.event.block.Action.RIGHT_CLICK_AIR&&e.getAction()!=org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK)return; ItemStack it=e.getItem(); if(it==null||!it.hasItemMeta())return; String item=it.getItemMeta().getPersistentDataContainer().get(itemKey,PersistentDataType.STRING); if(item==null)return; e.setCancelled(true); Player p=e.getPlayer(); if(!power(p).equals(item)){p.sendMessage("§cThis item is not bound to your power.");return;} activate(p,item); }
  @EventHandler public void move(PlayerMoveEvent e){ Player p=e.getPlayer(); ItemStack boots=p.getInventory().getBoots(); if(boots!=null&&boots.hasItemMeta()){String v=boots.getItemMeta().getPersistentDataContainer().get(itemKey,PersistentDataType.STRING); if("SPEED".equals(v)&&"SPEED".equals(power(p))) p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,40,1,true,false));} }
  private void activate(Player p,String s){long now=System.currentTimeMillis(),ready=cooldowns.getOrDefault(p.getUniqueId(),0L);if(now<ready){p.sendMessage("§cCooldown: "+((ready-now+999)/1000)+"s");return;} switch(s){case "LIGHTNING"->{Block b=p.getTargetBlockExact(20);if(b==null){p.sendMessage("§cLook at a block within 20 blocks.");return;}Location l=b.getLocation().add(.5,1,.5);p.getWorld().strikeLightningEffect(l);for(Entity x:p.getWorld().getNearbyEntities(l,3,3,3))if(x instanceof LivingEntity le&&!x.equals(p))le.damage(4,p);cool(p,18);}
  case "FIRE"->{for(Entity x:p.getWorld().getNearbyEntities(p.getLocation(),4,3,4))if(x instanceof LivingEntity le&&!x.equals(p)){le.setFireTicks(60);le.damage(3,p);}cool(p,20);}
  case "ICE"->{for(Entity x:p.getWorld().getNearbyEntities(p.getLocation(),5,3,5))if(x instanceof LivingEntity le&&!x.equals(p))le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,100,2));cool(p,20);}
  case "TELEPORT"->{Block b=p.getTargetBlockExact(12);if(b==null){p.sendMessage("§cLook at a destination within 12 blocks.");return;}Block land=b.getRelative(BlockFace.UP);if(!land.isPassable()||!land.getRelative(BlockFace.UP).isPassable()){p.sendMessage("§cUnsafe destination.");return;}Location l=land.getLocation().add(.5,0,.5);l.setDirection(p.getLocation().getDirection());p.teleport(l);cool(p,15);}
  case "SPEED"->{p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,240,1));cool(p,25);}}
  }
  private void cool(Player p,int seconds){cooldowns.put(p.getUniqueId(),System.currentTimeMillis()+seconds*1000L);p.sendMessage("§aPower activated! §7Cooldown: "+seconds+"s");}
  @Override public boolean onCommand(CommandSender s,Command c,String label,String[] a){if(!(s instanceof Player p)){s.sendMessage("Players only.");return true;}if(a.length==0||a[0].equalsIgnoreCase("info")){p.sendMessage("§6Your permanent power: §e"+pretty(power(p)));return true;}if(!s.hasPermission("powersmp.admin")){s.sendMessage("§cNo permission.");return true;}if(a.length>=2&&(a[0].equalsIgnoreCase("reroll")||a[0].equalsIgnoreCase("set"))){Player t=Bukkit.getPlayerExact(a[1]);if(t==null){s.sendMessage("§cPlayer must be online.");return true;}String v=a[0].equalsIgnoreCase("reroll")?powers.get(new Random().nextInt(powers.size())):(a.length>2?a[2].toUpperCase(Locale.ROOT):"");if(!powers.contains(v)){s.sendMessage("Use lightning, fire, ice, teleport, speed.");return true;}getConfig().set("players."+t.getUniqueId(),v);saveConfig();givePowerItem(t,v);s.sendMessage("§aAssigned "+pretty(v)+" to "+t.getName());return true;}s.sendMessage("§e/power info | /power reroll <player> | /power set <player> <power>");return true;}
}
