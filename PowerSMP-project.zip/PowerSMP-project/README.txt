PowerSMP source project

This is source code, not a ready-to-install JAR. Build it with Java 21 and Maven against the Paper API repository.
GitHub build: upload this folder's contents to a new GitHub repository, open Actions, run "Build PowerSMP", then download the PowerSMP artifact from the completed workflow.
Install the resulting JAR into the server's plugins folder while the server is stopped. Keep a backup first.

Commands: /power info; OP: /power reroll <online-player>; /power set <online-player> <lightning|fire|ice|teleport|speed>.
Abilities: right-click the assigned tagged item; speed requires wearing tagged diamond boots. First-join assignment is stored in plugins/PowerSMP/config.yml.
